package androidx.coordinatorlayout;

import com.aero.browser.R;

/* renamed from: androidx.coordinatorlayout.R */
public final class C0131R {

    /* renamed from: androidx.coordinatorlayout.R$attr */
    public static final class attr {
        public static final int alpha = 2130772318;
        public static final int coordinatorLayoutStyle = 2130771983;
        public static final int font = 2130772354;
        public static final int fontProviderAuthority = 2130772347;
        public static final int fontProviderCerts = 2130772350;
        public static final int fontProviderFetchStrategy = 2130772351;
        public static final int fontProviderFetchTimeout = 2130772352;
        public static final int fontProviderPackage = 2130772348;
        public static final int fontProviderQuery = 2130772349;
        public static final int fontStyle = 2130772353;
        public static final int fontVariationSettings = 2130772356;
        public static final int fontWeight = 2130772355;
        public static final int keylines = 2130772321;
        public static final int layout_anchor = 2130772324;
        public static final int layout_anchorGravity = 2130772326;
        public static final int layout_behavior = 2130772323;
        public static final int layout_dodgeInsetEdges = 2130772328;
        public static final int layout_insetEdge = 2130772327;
        public static final int layout_keyline = 2130772325;
        public static final int statusBarBackground = 2130772322;
        public static final int ttcIndex = 2130772357;

        public attr() {
        }
    }

    public C0131R() {
    }

    /* renamed from: androidx.coordinatorlayout.R$color */
    public static final class color {
        public static final int notification_action_color_filter = 2131689472;
        public static final int notification_icon_bg_color = 2131689553;
        public static final int ripple_material_light = 2131689563;
        public static final int secondary_text_default_material_light = 2131689565;

        public color() {
        }
    }

    /* renamed from: androidx.coordinatorlayout.R$dimen */
    public static final class dimen {
        public static final int compat_button_inset_horizontal_material = 2131427420;
        public static final int compat_button_inset_vertical_material = 2131427421;
        public static final int compat_button_padding_horizontal_material = 2131427422;
        public static final int compat_button_padding_vertical_material = 2131427423;
        public static final int compat_control_corner_material = 2131427424;
        public static final int compat_notification_large_icon_max_height = 2131427425;
        public static final int compat_notification_large_icon_max_width = 2131427426;
        public static final int notification_action_icon_size = 2131427526;
        public static final int notification_action_text_size = 2131427527;
        public static final int notification_big_circle_margin = 2131427528;
        public static final int notification_content_margin_start = 2131427353;
        public static final int notification_large_icon_height = 2131427529;
        public static final int notification_large_icon_width = 2131427530;
        public static final int notification_main_column_padding_top = 2131427354;
        public static final int notification_media_narrow_margin = 2131427355;
        public static final int notification_right_icon_size = 2131427531;
        public static final int notification_right_side_padding_top = 2131427351;
        public static final int notification_small_icon_background_padding = 2131427532;
        public static final int notification_small_icon_size_as_large = 2131427533;
        public static final int notification_subtext_size = 2131427534;
        public static final int notification_top_pad = 2131427535;
        public static final int notification_top_pad_large_text = 2131427536;

        public dimen() {
        }
    }

    /* renamed from: androidx.coordinatorlayout.R$drawable */
    public static final class C0132drawable {
        public static final int notification_action_background = 2130837626;
        public static final int notification_bg = 2130837627;
        public static final int notification_bg_low = 2130837628;
        public static final int notification_bg_low_normal = 2130837629;
        public static final int notification_bg_low_pressed = 2130837630;
        public static final int notification_bg_normal = 2130837631;
        public static final int notification_bg_normal_pressed = 2130837632;
        public static final int notification_icon_background = 2130837633;
        public static final int notification_template_icon_bg = 2130837641;
        public static final int notification_template_icon_low_bg = 2130837642;
        public static final int notification_tile_bg = 2130837634;
        public static final int notify_panel_notification_icon_bg = 2130837635;

        public C0132drawable() {
        }
    }

    /* renamed from: androidx.coordinatorlayout.R$id */
    public static final class C0133id {
        public static final int action_container = 2131755212;
        public static final int action_divider = 2131755223;
        public static final int action_image = 2131755213;
        public static final int action_text = 2131755214;
        public static final int actions = 2131755224;
        public static final int async = 2131755105;
        public static final int blocking = 2131755106;
        public static final int bottom = 2131755045;
        public static final int chronometer = 2131755222;
        public static final int end = 2131755046;
        public static final int forever = 2131755107;
        public static final int icon = 2131755147;
        public static final int icon_group = 2131755225;
        public static final int info = 2131755218;
        public static final int italic = 2131755108;
        public static final int left = 2131755047;
        public static final int line1 = 2131755015;
        public static final int line3 = 2131755016;
        public static final int none = 2131755064;
        public static final int normal = 2131755067;
        public static final int notification_background = 2131755220;
        public static final int notification_main_column = 2131755216;
        public static final int notification_main_column_container = 2131755215;
        public static final int right = 2131755048;
        public static final int right_icon = 2131755219;
        public static final int right_side = 2131755217;
        public static final int start = 2131755049;
        public static final int tag_transition_group = 2131755029;
        public static final int tag_unhandled_key_event_manager = 2131755030;
        public static final int tag_unhandled_key_listeners = 2131755031;
        public static final int text = 2131755032;
        public static final int text2 = 2131755033;
        public static final int time = 2131755221;
        public static final int title = 2131755037;
        public static final int top = 2131755050;

        public C0133id() {
        }
    }

    /* renamed from: androidx.coordinatorlayout.R$integer */
    public static final class integer {
        public static final int status_bar_notification_info_maxnum = 2131623951;

        public integer() {
        }
    }

    /* renamed from: androidx.coordinatorlayout.R$layout */
    public static final class layout {
        public static final int notification_action = 2130968629;
        public static final int notification_action_tombstone = 2130968630;
        public static final int notification_template_custom_big = 2130968631;
        public static final int notification_template_icon_group = 2130968632;
        public static final int notification_template_part_chronometer = 2130968633;
        public static final int notification_template_part_time = 2130968634;

        public layout() {
        }
    }

    /* renamed from: androidx.coordinatorlayout.R$string */
    public static final class string {
        public static final int status_bar_notification_info_overflow = 2131361839;

        public string() {
        }
    }

    /* renamed from: androidx.coordinatorlayout.R$style */
    public static final class C0134style {
        public static final int TextAppearance_Compat_Notification = 2131492985;
        public static final int TextAppearance_Compat_Notification_Info = 2131492986;
        public static final int TextAppearance_Compat_Notification_Line2 = 2131493162;
        public static final int TextAppearance_Compat_Notification_Time = 2131492987;
        public static final int TextAppearance_Compat_Notification_Title = 2131492988;
        public static final int Widget_Compat_NotificationActionContainer = 2131492993;
        public static final int Widget_Compat_NotificationActionText = 2131492994;
        public static final int Widget_Support_CoordinatorLayout = 2131493362;

        public C0134style() {
        }
    }

    /* renamed from: androidx.coordinatorlayout.R$styleable */
    public static final class styleable {
        public static final int[] ColorStateListItem = {16843173, 16843551, R.attr.alpha};
        public static final int ColorStateListItem_alpha = 2;
        public static final int ColorStateListItem_android_alpha = 1;
        public static final int ColorStateListItem_android_color = 0;
        public static final int[] CoordinatorLayout = {R.attr.keylines, R.attr.statusBarBackground};
        public static final int[] CoordinatorLayout_Layout = {16842931, R.attr.layout_behavior, R.attr.layout_anchor, R.attr.layout_keyline, R.attr.layout_anchorGravity, R.attr.layout_insetEdge, R.attr.layout_dodgeInsetEdges};
        public static final int CoordinatorLayout_Layout_android_layout_gravity = 0;
        public static final int CoordinatorLayout_Layout_layout_anchor = 2;
        public static final int CoordinatorLayout_Layout_layout_anchorGravity = 4;
        public static final int CoordinatorLayout_Layout_layout_behavior = 1;
        public static final int CoordinatorLayout_Layout_layout_dodgeInsetEdges = 6;
        public static final int CoordinatorLayout_Layout_layout_insetEdge = 5;
        public static final int CoordinatorLayout_Layout_layout_keyline = 3;
        public static final int CoordinatorLayout_keylines = 0;
        public static final int CoordinatorLayout_statusBarBackground = 1;
        public static final int[] FontFamily = {R.attr.fontProviderAuthority, R.attr.fontProviderPackage, R.attr.fontProviderQuery, R.attr.fontProviderCerts, R.attr.fontProviderFetchStrategy, R.attr.fontProviderFetchTimeout};
        public static final int[] FontFamilyFont = {16844082, 16844083, 16844095, 16844143, 16844144, R.attr.fontStyle, R.attr.font, R.attr.fontWeight, R.attr.fontVariationSettings, R.attr.ttcIndex};
        public static final int FontFamilyFont_android_font = 0;
        public static final int FontFamilyFont_android_fontStyle = 2;
        public static final int FontFamilyFont_android_fontVariationSettings = 4;
        public static final int FontFamilyFont_android_fontWeight = 1;
        public static final int FontFamilyFont_android_ttcIndex = 3;
        public static final int FontFamilyFont_font = 6;
        public static final int FontFamilyFont_fontStyle = 5;
        public static final int FontFamilyFont_fontVariationSettings = 8;
        public static final int FontFamilyFont_fontWeight = 7;
        public static final int FontFamilyFont_ttcIndex = 9;
        public static final int FontFamily_fontProviderAuthority = 0;
        public static final int FontFamily_fontProviderCerts = 3;
        public static final int FontFamily_fontProviderFetchStrategy = 4;
        public static final int FontFamily_fontProviderFetchTimeout = 5;
        public static final int FontFamily_fontProviderPackage = 1;
        public static final int FontFamily_fontProviderQuery = 2;
        public static final int[] GradientColor = {16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 16844050, 16844051};
        public static final int[] GradientColorItem = {16843173, 16844052};
        public static final int GradientColorItem_android_color = 0;
        public static final int GradientColorItem_android_offset = 1;
        public static final int GradientColor_android_centerColor = 7;
        public static final int GradientColor_android_centerX = 3;
        public static final int GradientColor_android_centerY = 4;
        public static final int GradientColor_android_endColor = 1;
        public static final int GradientColor_android_endX = 10;
        public static final int GradientColor_android_endY = 11;
        public static final int GradientColor_android_gradientRadius = 5;
        public static final int GradientColor_android_startColor = 0;
        public static final int GradientColor_android_startX = 8;
        public static final int GradientColor_android_startY = 9;
        public static final int GradientColor_android_tileMode = 6;
        public static final int GradientColor_android_type = 2;

        public styleable() {
        }
    }
}
